from collections import ChainMap,deque

# 1) the Write a Python program that takes a list of numbers as input, removes duplicates, and sorts the list in ascending order.
# Note: first i'm going to create the function to store that list 
def storeList(list_usage):
    # Info: i'm going to first remove duplicate from the list
    remove_dup=set(list_usage)
    # Info: i'm going to return back my list to ascending order
    ascending_order=sorted(remove_dup)
    return ascending_order
list_usage=[3, 1, 4, 1, 5, 9, 2, 6, 5]
# BUG print(list_usage)
print(storeList(list_usage))

# 2) Write a Python function that accepts a tuple of numbers and returns a new tuple with each number doubled.
#Info creating the function to get that parameter to get tha taple
def double_numbers(input_tuple):
    return tuple(x * 2 for x in input_tuple)
input_tuple = (1, 2, 3, 4)
output_tuple = double_numbers(input_tuple)
print(output_tuple)  

# 3) Write a Python program that accepts a dictionary of student names and their grades. The program should return the name of the student with the highest grade.
def highest_grade_student(grades):
    return max(grades, key=grades.get)

grades = {"John": 85, "Mary": 92, "Alex": 89}
top_student = highest_grade_student(grades)
print(top_student) 

# 4)Write a Python program that takes two sets of numbers and returns their intersection.
def intersect_sets(set1, set2):
    return set1.intersection(set2)

set1 = {1, 2, 3, 4}
set2 = {3, 4, 5, 6}
intersection = intersect_sets(set1, set2)
print(intersection) 


# 5) Write a Python program that takes a list of frozen sets and combines them into a single frozen set without duplicates.
def combine_frozen_sets(*frozen_sets):
    combined_set = frozenset()
    for fs in frozen_sets:
        combined_set = combined_set.union(fs)
    return combined_set

frozen_set1 = frozenset([1, 2, 3])
frozen_set2 = frozenset([3, 4, 5])
combined_frozen_set = combine_frozen_sets(frozen_set1, frozen_set2)
print(combined_frozen_set)

# 6) Write a Python program that merges two dictionaries using ChainMap and prints the vmerged dictionary.


def merge_dictionaries(dict1, dict2):
    merged_dict = ChainMap(dict1, dict2)
    return dict(merged_dict)

dict1 = {"name": "John", "age": 25}
dict2 = {"city": "New York", "country": "USA"}
merged_dictionary = merge_dictionaries(dict1, dict2)
print(merged_dictionary)  


# 7) Write a Python program that uses a deque to add elements to both ends and then removes them from both ends.
def manipulate_deque():
    dq = deque([1, 2, 3])
    dq.append(4)         
    dq.appendleft(0)    
    dq.pop()            
    dq.popleft()        
    return dq

result_deque = manipulate_deque()
print(result_deque)  
